#!/bin/bash
pause()
{
echo "Press any key to quit:"
read -n1 -s key
exit 1
}
echo "start to make update.img..."
if [ ! -f "parameter.txt" ]; then
	echo "Error:No found parameter!"
	exit 1
fi
if [ ! -f "package-file" ]; then
	echo "Error:No found package-file!"
	exit 1
fi

if [ ! -f "MiniLoaderAll.bin" ]; then
	echo "Error:No found MiniLoaderAll.bin!"
	exit 1
fi
TAG=RK$(dd if=MiniLoaderAll.bin bs=1 count=4 skip=21 status=none | rev)
../afptool -pack ./ update.raw.img || pause
../rkImageMaker -$TAG MiniLoaderAll.bin update.raw.img update.img -os_type:androidos || pause
echo "Making ./update.img OK."
#echo "Press any key to quit:"
#read -n1 -s key
exit $?
